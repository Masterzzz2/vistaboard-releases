#!/bin/bash
# VistaBoard Update-Installer
# Aufruf: sudo /usr/local/bin/vistaboard-update.sh /tmp/vb-dist-new-<TS>

set -u
SRC="${1:-}"
APP=/home/vistaboard/app
BAK="/home/vistaboard/app.bak"

log(){ echo "[update] $*"; }
fail(){ echo "[update] FAIL: $*" >&2; exit 1; }

case "$SRC" in
  /tmp/vb-dist-new-*) ;;
  *) fail "Quelle muss /tmp/vb-dist-new-* sein (war: $SRC)" ;;
esac

[ -d "$SRC" ] || fail "Quelle $SRC existiert nicht"
[ -f "$SRC/index.js" ] || fail "Quelle enthält kein index.js"
[ -d "$SRC/public" ] || fail "Quelle enthält kein public/"
[ -f "$SRC/VERSION" ] || fail "Quelle enthält kein VERSION"
[ -f "$SRC/package.json" ] || fail "Quelle enthält kein package.json"

log "Quelle: $SRC"
log "Backup nach $BAK"
rm -rf "$BAK"
cp -al "$APP" "$BAK" 2>/dev/null || cp -r "$APP" "$BAK"

log "Installiere neue Version..."
# Copy new files, keep data/ and .env and node_modules
rsync -a --delete \
  --exclude='data/' \
  --exclude='.env' \
  --exclude='node_modules/' \
  "$SRC/" "$APP/" || fail "rsync fehlgeschlagen"

# Install dependencies if package.json changed
if [ -f "$APP/package.json" ]; then
  log "Installiere Abhaengigkeiten..."
  cd "$APP" && npm install --omit=dev --no-audit --no-fund 2>&1 || log "npm install Warnung (nicht kritisch)"
fi

# Copy display-helper.js to /usr/local/bin if present
if [ -f "$SRC/display-helper.js" ]; then
  cp "$SRC/display-helper.js" /usr/local/bin/vistaboard-display-helper.js 2>/dev/null || true
fi

# Self-update: copy new update script to /usr/local/bin if present
if [ -f "$SRC/vistaboard-update.sh" ]; then
  cp "$SRC/vistaboard-update.sh" /usr/local/bin/vistaboard-update.sh
  chmod +x /usr/local/bin/vistaboard-update.sh
  log "Update-Script aktualisiert"
fi

chown -R vistaboard:vistaboard "$APP"

# Clear kiosk browser cache BEFORE restart so it's ready for reboot
KIOSK_USER=$(grep -oP '(?<=VISTABOARD_KIOSK_USER=)\S+' "$APP/.env" 2>/dev/null || echo "")
if [ -z "$KIOSK_USER" ]; then
  KIOSK_USER=$(getent passwd 1000 2>/dev/null | cut -d: -f1 || echo "")
fi
if [ -n "$KIOSK_USER" ]; then
  KIOSK_HOME=$(eval echo "~$KIOSK_USER")
  log "Browser-Cache loeschen fuer $KIOSK_USER..."
  rm -rf "$KIOSK_HOME/.cache/vistaboard-kiosk-profile/Default/Cache" \
         "$KIOSK_HOME/.cache/vistaboard-kiosk-profile/Default/Code Cache" \
         "$KIOSK_HOME/.cache/vistaboard-kiosk-profile/Default/GPUCache" \
         "$KIOSK_HOME/.cache/vistaboard-kiosk-profile/Default/Service Worker" \
         "$KIOSK_HOME/.cache/chromium/Default/Cache" \
         "$KIOSK_HOME/.cache/chromium/Default/Code Cache" 2>/dev/null || true
fi

# Schedule reboot OUTSIDE the vistaboard cgroup so systemctl restart won't kill it
log "Plane automatischen Reboot nach Update..."
systemd-run --scope --description="VistaBoard post-update reboot" bash -c "sleep 30 && reboot" 2>/dev/null &

log "Starte Service neu..."
systemctl restart vistaboard

log "Health-Check..."
OK=0
for _ in $(seq 1 30); do
  if curl -sf -o /dev/null http://127.0.0.1:3000/ 2>/dev/null; then
    OK=1
    break
  fi
  sleep 1
done

if [ "$OK" = "1" ]; then
  log "Update erfolgreich"
  NEW_VER=$(cat "$APP/VERSION" 2>/dev/null || echo "?")
  log "Neue Version: $NEW_VER"
  rm -rf "$BAK"
  log "System wird in ca. 30 Sekunden neu gestartet..."
  exit 0
fi

log "Health-Check fehlgeschlagen - Rollback..."
# Cancel the scheduled reboot on failure
systemctl stop "run-*" 2>/dev/null || true
rsync -a --delete "$BAK/" "$APP/"
chown -R vistaboard:vistaboard "$APP"
systemctl restart vistaboard
fail "ROLLED_BACK"
