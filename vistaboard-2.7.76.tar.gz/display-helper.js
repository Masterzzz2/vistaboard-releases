#!/usr/bin/env node
const http = require("http");
const { execFile } = require("child_process");

const PORT = Number(process.env.VISTABOARD_DISPLAY_HELPER_PORT || 3997);
const OUTPUT = process.env.VISTABOARD_DISPLAY_OUTPUT || "HDMI-A-1";
process.env.XDG_RUNTIME_DIR = process.env.XDG_RUNTIME_DIR || "/run/user/1000";
process.env.WAYLAND_DISPLAY = process.env.WAYLAND_DISPLAY || "wayland-0";

function run(args) {
  return new Promise((resolve, reject) => {
    execFile("wlr-randr", args, { timeout: 8000 }, (error, stdout, stderr) => {
      if (error) reject(new Error((stderr || error.message || "wlr-randr failed").trim()));
      else resolve({ stdout, stderr });
    });
  });
}

function getStatus() {
  return new Promise((resolve, reject) => {
    execFile("wlr-randr", [], { timeout: 8000 }, (error, stdout, stderr) => {
      if (error) return reject(new Error((stderr || error.message || "wlr-randr failed").trim()));
      const block = stdout.split(/\n(?=\S)/).find((part) => part.startsWith(`${OUTPUT} `)) || stdout;
      const enabled = /Enabled:\s+yes/i.test(block);
      const m = block.match(/Transform:\s+(\S+)/i);
      resolve({ enabled, transform: m ? m[1] : "normal" });
    });
  });
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => body += chunk);
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); } catch (e) { reject(e); }
    });
  });
}

function send(res, status, obj) {
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(obj));
}

function normalizeTransform(t) {
  return t === "270" || t === "90" || t === "180" || t === "flipped" ? t : "normal";
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "GET" && req.url === "/health") return send(res, 200, { success: true });
    if (req.method === "GET" && req.url === "/display/status") {
      const status = await getStatus();
      return send(res, 200, { success: true, ...status });
    }
    if (req.method !== "POST") return send(res, 405, { success: false, error: "Method not allowed" });
    const body = await readJson(req);
    const transform = normalizeTransform(body.transform);
    if (req.url === "/display/rotate") {
      await run(["--output", OUTPUT, "--transform", transform]);
      return send(res, 200, { success: true, state: "on", transform });
    }
    if (req.url === "/display/power") {
      if (body.state === "off") {
        await run(["--output", OUTPUT, "--off"]);
        return send(res, 200, { success: true, state: "off" });
      }
      await run(["--output", OUTPUT, "--on", "--transform", transform]);
      return send(res, 200, { success: true, state: "on", transform });
    }
    send(res, 404, { success: false, error: "Not found" });
  } catch (e) {
    send(res, 500, { success: false, error: e.message || String(e) });
  }
});

server.listen(PORT, "127.0.0.1", () => console.log(`VistaBoard display helper listening on ${PORT}`));
